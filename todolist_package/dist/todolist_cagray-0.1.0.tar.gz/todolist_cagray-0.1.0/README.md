# README #

Practice uploading a project to PyPI Test.
Todolist application.